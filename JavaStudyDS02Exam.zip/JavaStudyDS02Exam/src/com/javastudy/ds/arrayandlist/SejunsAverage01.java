package com.javastudy.ds.arrayandlist;

import java.util.Scanner;

/* 평균 구하기
 * 문제 출처 : 백준 온라인 저지 1546
 * https://www.acmicpc.net/problem/1546
 * 
 * 문제 분석 :
 * 문제를 읽어 보면 세준이는 최고 점수를 기준으로 점수를 다시 계산 한다.
 * 그러므로 점수를 입력 받아서 최고 점수를 따로 저장하고 한 과목의 점수를 계산하는
 * 식은 점수 / M * 100 이므로 만약 3과목의 평균을 구하는 식은 다음과 같다
 * (과목1 / M * 100 + 과목2 / M * 100 + 과목3 / M * 100) / 3 이 된다.
 * 이를 간단히 정리하면 (과목1 + 과목2 + 과목3) * 100 / M / 3 과 같다.
 * 위의 수식은 다시 간단히 정리하면 -> 총점 * 100 / M / 3과 같다.
 * 
 * 가상코드 :
 * 본격적으로 코드를 작성하기 전에 코드의 흐름을 생각하면서 논리적인 가상 코드를 작성해 보자.
 * 
 * 과목의 수 N 값 입력 받기
 * 점수를 저장할 길이가 N인 score 배열 선언
 * 
 * for(score 배열 길이만큼 반복) {
 *		score 배열에 입력 받은 각 점수를 저장
 * }
 * 
 * 최고 점수를 저장할 int 변수 max 선언
 * 전체 과목의 총점을 저장할 long 변수 sum 선언
 *  
 * for(score 배열 길이만큼 반복) {
 * 		최고 점수는 변수 max에 저장하고 모든 점수는 변수 sum에 저장
 * }
 * 
 * sum * 100 / max / N의 결과 값 출력
 **/
public class SejunsAverage01 {

	public static void main(String[] args) {
		
		// 사용자 입력을 받기 위한 스캐너 객체 생성
		Scanner sc = new Scanner(System.in);
		
		// 과목의 수 N 값 입력 받기
		int N = sc.nextInt();
		
		// 점수를 저장할 길이가 N인 score 배열 선언
		int[] score = new int[N];
		
		for(int i = 0; i < score.length; i++) {
			// score 배열에 입력 받은 각 점수를 저장
			score[i] = sc.nextInt();
		}
		
		int max = 0;
		int sum = 0;
		
		for(int i = 0; i < score.length; i++) {

			// 최고 점수는 변수 max에 저장하고 모든 점수는 변수 sum에 저장
			if(score[i] > max) {
				max = score[i];
			}
			sum += score[i];
		}
		System.out.println(sum * 100.0 / max / N);
		
		// 스캐너 닫기
		sc.close();
	}

}
