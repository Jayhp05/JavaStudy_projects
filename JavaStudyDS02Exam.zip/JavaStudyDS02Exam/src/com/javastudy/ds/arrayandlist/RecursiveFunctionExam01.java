package com.javastudy.ds.arrayandlist;

// 배열에서 최대 값 찾기
public class RecursiveFunctionExam01 {

	public static void main(String[] args) {
		
		int arr[] = {20, 70, 90, 50, 60, 100, 40, 30};
		System.out.println("배열에서 가장 큰 값(메서드) : " + arrayMaxNum(arr));
		System.out.println("배열에서 가장 큰 값(재귀함수) : " + arrayMaxNum(arr, arr.length));

	}
	
	// 배열에서 지정한 갯 수 범위에서 가장 큰 값을 구하는 재귀 함수
	public static int arrayMaxNum(int[] arr, int n) {
		int x;
		if(n == 1) {
			return arr[0];
		} else {
			x = arrayMaxNum(arr, n-1);
		}
		
		if(x > arr[n - 1]) {
			return x;			
		} else {
			return arr[n - 1];
		}
	}
	
	// 배열에서 지정한 갯 수 범위에서 가장 큰 값을 구하여 반환하는 함수
	public static int arrayMaxNum(int[] arr) {
		int max = 0;
		for(int i = 0; i < arr.length; i++) {			
			if(arr[i] > max) {
				max = arr[i];
			}
		}
		return max;
	}
}
