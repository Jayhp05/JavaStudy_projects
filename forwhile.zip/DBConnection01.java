package com.javastudy.ch03.forwhile;

public class DBConnection01 {
	public static void main(String[] args) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDrive");
		}
		catch (ClassNotFoundException e) {
			// TODO: handle exception
			
			e.printStackTrace();
		}
		
		System.out.println("드라이버 로딩 OK");
	}
}
