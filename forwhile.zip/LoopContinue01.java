package com.javastudy.ch03.forwhile;

// 반복문의 처음으로 이동하는 continue 문 사용하기
public class LoopContinue01 {
	
	public static void main(String[] args) {
		
		int sum = 0;
		
		for(int i = 1; i <= 100; i++) {
			if(i % 2 == 0) {
				continue;
			}
			else {
				sum += i;
			}
		}
		
		System.out.println("1 ~ 100까지 홀 수의 합 : " + sum);
	}
}
