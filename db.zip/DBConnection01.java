package com.javastudy.ch03.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnection01 {
	
	static final String driver = "oracle.jdbc.driver.OracleDriver";
	static final String url = "jdbc:oracle:thin:@localhost:1521/xe";
	static final String user = "hr";
	static final String password = "hr";
	
	public static void main(String[] args) {
		try {
//			드라이버 로딩
			Class.forName(driver);
			
//			DB접속
			Connection conn = DriverManager.getConnection(url, user, password);
			
//			SQL 쿼리문 실행
			PreparedStatement pstmt =
				conn.prepareStatement(
									"Select e.empno, e.ename, e.gender, e.job, e.sal, d.dname "
									+ "From emp e, dept d "
									+ "Where e.deptno = d.deptno "
									+ "	AND d.deptno = 30"
									+ "ORDER BY empno");
			
			ResultSet rs = pstmt.executeQuery();
			
			System.out.println("### 회원 리스트 ###");
			System.out.println("사원\t이름\t성별\t직급\t급여\t부서");
			
			while(rs.next()) {
//				rs.getInt();
//				rs.getString();
				
				System.out.printf("%d\t%s\t%s\t%s\t%s\t%s\n",
						rs.getInt("empno"), rs.getString(2), rs.getString(3),
						rs.getString("job"), rs.getString("sal"), rs.getString("dname"));
			}
			
		}
		catch (ClassNotFoundException e) {
			// TODO: handle exception
			
			e.printStackTrace();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("드라이버 로딩 OK");
	}
}
