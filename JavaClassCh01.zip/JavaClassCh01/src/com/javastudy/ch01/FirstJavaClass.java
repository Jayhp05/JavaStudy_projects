package com.javastudy.ch01;

public class FirstJavaClass {
//	프로그램의 시작점 - 진입점 - 함수 -
//	자바 객체지향에서 함수 - 메소드(Method)
	public static void main(String[] args) {
		
		int x = 30;
		int y = 50;
		
		char ch = 'A'; // 문자 하나
		
		String a = "Hello World"; // 문자열 
		
		System.out.println(a);
		System.out.println(ch);
		System.out.println("x + y = " + (x + y));
		
//		접근제어 4가지 - 기초적인 접근제어자 알아두기
//		private
//		public
//		default
//		protected
		
	}
	
}
